# AI IT Helpdesk Agent — GitHub Pages

A college-project web application for intelligent IT troubleshooting and support ticket creation.

## Technology

- HTML
- CSS
- JavaScript
- GitHub Pages

## Features

- Chat-style helpdesk
- Intelligent keyword-based issue identification
- Troubleshooting for Wi-Fi, passwords, printers, email, slow computers, software, and hardware
- Support ticket creation
- Ticket ID generation
- Priority selection
- Browser local storage for recent tickets
- Responsive design for mobile and desktop

## GitHub Pages deployment

1. Create a GitHub repository named `AI-IT-Helpdesk-Agent`.
2. Upload `index.html` and this `README.md`.
3. Open the repository's **Settings**.
4. Select **Pages**.
5. Under **Build and deployment**, choose **Deploy from a branch**.
6. Select the `main` branch and `/ (root)`.
7. Click **Save**.
8. Wait for GitHub Pages to publish the site.

Your URL will normally be:

`https://YOUR-USERNAME.github.io/AI-IT-Helpdesk-Agent/`

Replace `YOUR-USERNAME` with your GitHub username.

## Academic note

The interface is presented as an AI IT Helpdesk Agent, while the current demo uses a local knowledge base and intelligent keyword matching. No external API key is required.
